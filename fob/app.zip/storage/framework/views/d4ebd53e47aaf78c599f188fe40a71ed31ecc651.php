<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
              <div class="panel-heading">Notification Receipts</div>

          <div class="panel-body">
              
          <form class="form-horizontal" action="<?php echo e(url('add_nreceipt')); ?>" method="POST">
                             <?php echo e(csrf_field()); ?>


            <div class="col-md-6 form-group">
                <label class="control-label col-md-6" for="note">Notification Id:</label> 
                
                <div class="col-md-6">
                    <input type="text" class="form-control" id="note" name="notifications" value="<?php echo e($lastid[0]->id); ?>" placeholder="<?php echo e($lastid[0]->description); ?>" readonly>
                </div>
                  
                <?php if(Session::has('alert-select')): ?>
                <div>
                <strong style="color:red">Select minimum one district!</strong> <?php echo e(Session::get('message', '')); ?>

                </div>
                <?php endif; ?>
                  
            </div>
            
            <div class="col-md-6 form-group">
                <label class="control-label col-sm-6" for="notification">Notification:</label> 
                <div class="col-sm-6">
              
                <textarea class="form-control" id="notification" placeholder=""  value="<?php echo e($lastid[0]->description); ?>"    readonly><?php echo e($lastid[0]->description); ?></textarea>
                </div>
            </div>
    

            <?php 
                $zonename = DB::table('zones')->pluck('zone');
                $no_of_zones=count($zones);
            ?>
            
            
            <?php for($i = 0; $i <$no_of_zones; $i++): ?>
                <div class="col-sm-6 form-group">
                    <label class="control-label col-sm-6" for="zone"><?php echo e($zonename[$i]); ?> :</label>
    
                <div class="col-sm-6">
                    <input type="checkbox" class="parent" data-group=".group<?php echo e($i); ?>" data-group=".group<?php echo e($i); ?>" checked /> Select All<br>
                  
                    <?php $__currentLoopData = $zones[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="checkbox" class="group<?php echo e($i); ?>" name="zones[]" value="<?php echo e($zone->id); ?>" checked><?php echo e($zone->district); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                </div>
            <?php endfor; ?>
            

            <div class="form-group">        
                          <div class="col-sm-offset-3 col-sm-5">
                            <button type="submit" class="btn btn-default" name="submit">Submit</button>
                            <a class="btn btn-default btn-close" href="/fob/notificationonly_delete/<?php echo e($lastid[0]->id); ?>">Cancel</a>
                          </div>
            </div>

            </form>
            </div>
            
<script>
  $(".parent").each(function(index){
    var group = $(this).data("group");
    var parent = $(this);

    parent.change(function(){  //"select all" change 
         $(group).prop('checked', parent.prop("checked"));
    });
    $(group).change(function(){ 
        parent.prop('checked', false);
        if ($(group+':checked').length == $(group).length ){
            parent.prop('checked', true);
        }
    });
});
</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>


                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>