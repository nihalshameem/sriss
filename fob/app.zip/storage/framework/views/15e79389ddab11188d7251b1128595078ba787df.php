<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;background-color:#F3F8FA;">Poll Details<a href="<?php echo e(url( 'add_poll_questions' )); ?>"><i class="fa fa-plus-square fa-lg" style="float:right"></i></a>
                <a href="<?php echo e(url( 'poll_mass_delete' )); ?>" title="Mass Deletion"><i class="fa fa-trash fa-lg " style="float:right;padding-right: 12px"></i></a>
                
                </div>

                <div class="panel-body" style="text-align: left;">
                    
                <div class="col-md-3 form-group">
                  <input type="date" name="pollsearch" id="pollsearch" class="form-control">
                </div>
                <div class="col-md-3 form-group">
                  <input type="date" name="pollsearch1" id="pollsearch1" class="form-control">
                </div>
                    
                <table class="table">
                  <thead>
                    <tr>
                      
                      <th>Id</th>
                      <th>Question</th>
                      <th>From Date</th>
                      <th>To Date</th>
                      <th>Q Update</th>
                      <th>Receipt Update</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>  
                      <?php $__currentLoopData = $pollquestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pollquestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($pollquestion['id']); ?></td>
                          <td><?php echo e($pollquestion['question']); ?></td>
                          <td><?php echo e($pollquestion['from_date']); ?></td>
                          <td><?php echo e($pollquestion['to_date']); ?></td>
                          <td><a href="/fob/pollquestion_edit/<?php echo e($pollquestion['id']); ?>" ><i class="fa fa-edit fa-lg" style="text-align:cenetr;"></i></a></td>
                         <td><a href="/fob/poll_receipt_edit/<?php echo e($pollquestion['id']); ?>" ><i class="fa fa-edit fa-lg" style="text-align:cenetr;"></i></a></td>
                        <td><a href="/fob/poll_delete/<?php echo e($pollquestion['id']); ?>"><i class="fa fa-trash fa-lg" style="text-align:cenetr;"  onclick="return confirm('Are you sure, You want to delete?')"></i></a></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody> 
                </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('#pollsearch').on('change',function(){
      $value=$(this).val();
      $('#pollsearch1').on('change',function(){
      $value1=$(this).val();
      $.ajax({
        type : 'get',
        url : '<?php echo e(URL::to('pollsearch')); ?>',
        data : {'pollsearch':$value , 'pollsearch1':$value1},
        success:function(data){
          $('tbody').html(data);
        } 
      });
    })
    })
</script>

<script language="JavaScript" type="text/javascript">
function checkDelete(){
    return confirm('Are you sure?');
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>