<?php $__env->startSection('content'); ?>
<?php
$i=1;
?>

<table width="100%" cellpadding="10px" class="col-md-offset-2 col-md-10">
    <tr style="border-bottom:none"><th colspan="8" style="text-align: center;padding:10px;font-size:20px">Past year Advertisements<span class="label label-success"><?php echo e(count($thisyear_ads)); ?></span></th></tr>
    <tr style="padding:50px;height:50px">        
        <center>
        <td  colspan="8" style="border-right:none"><a href="<?php echo e(URL::previous()); ?>" style="color:blue;margin-left: 20px;padding:10px;font-size:25px;text-decoration:none"><i class="fa fa-arrow-left" aria-hidden="true"></i>
            </a>
        <a href="/fob/thisyear_ads_xlsx" style="color:purple;margin-left: 20px;padding:10px;font-size:25px"><i class="fa fa-download" aria-hidden="true"></i></a></td>
        </center>
    </tr>
<tr style="height:30px;background-color: brown;color:white;text-align:center;margin-left:25px;padding:10px">
    <th style="text-align:center;border:1px solid brown">Sl No.</th>
    <th style="text-align:center;border:1px solid brown">Booked date</th>
    <th style="text-align:center;border:1px solid brown">Description</th>
    <th style="text-align:center;border:1px solid brown">Company</th>
    <th style="text-align:center;border:1px solid brown">Link</th>
    <th style="text-align:center;border:1px solid brown">From_date</th>
    <th style="text-align:center;border:1px solid brown">To_date</th>
    <th style="text-align:center;border:1px solid brown">Active</th>
</tr>

<?php $__currentLoopData = $thisyear_ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thisyear_ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr style="height:20px;border:1px solid grey">
        <td style="padding:10px;text-align:center;border:1px solid grey"><?php echo e($i++); ?></td>
       <td style="padding:10px;text-align:center;border:1px solid grey"><?php echo e($thisyear_ad['created_at']); ?></td>
        <td style="padding:10px;text-align:center;border:1px solid grey"><?php echo e($thisyear_ad['description']); ?></td>
        <td style="padding:10px;text-align:center;border:1px solid grey"><?php echo e($thisyear_ad['company']); ?></td>
        <td style="padding:10px;text-align:center;border:1px solid grey"><?php echo e($thisyear_ad['link']); ?></td>
        <td style="padding:10px;text-align:center;border:1px solid grey"><?php echo e($thisyear_ad['from_date']); ?></td>
        <td style="padding:10px;text-align:center;border:1px solid grey"><?php echo e($thisyear_ad['to_date']); ?></td>
        <td style="padding:10px;text-align:center;border:1px solid grey"><?php echo e($thisyear_ad['active']); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>