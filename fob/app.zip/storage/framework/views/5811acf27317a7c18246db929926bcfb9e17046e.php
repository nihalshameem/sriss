<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row" style="margin-top:40px;">
        <div class="col-md-10 col-md-offset-2">
            
          
            
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>    
            
            
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;background-color:#F3F8FA;"><b>Visions</b><a href="<?php echo e(url( 'cfgVisionAdd' )); ?>"><i class="fa fa-plus-square fa-lg" style="float:right"></i></a>
                </div>
                
                <div class="panel-body" style="text-align: left;">
                <table class="table">
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>Vision</th>
                      <th>Update</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>  

                <?php $i =1; ?>
                    <?php $__currentLoopData = $cfgvisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                         <td><?php echo e($i++); ?></td>
                         <td><?php echo e($vision->vision); ?></td> 
                         <td><a href="/fob/cfgVisionEdit/<?php echo e($vision->id); ?>" ><i class="fa fa-edit fa-lg" style="text-align:cenetr;"></i></a></td>
                         <td><a href="/fob/cfgVisionDelete/<?php echo e($vision->id); ?>" onclick="return confirm('Are you sure,You want to delete?')"><i class="fa fa-trash fa-lg" style="text-align:cenetr;"></i></a></td>
                       </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody> 
                </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" >


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>