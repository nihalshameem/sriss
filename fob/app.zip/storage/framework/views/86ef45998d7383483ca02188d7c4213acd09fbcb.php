<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;background-color:#F3F8FA;">Feedback Details</div>

                <div class="panel-body" style="text-align: left;">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Member Id</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile No.</th>
                      <th>Whatsapp No.</th>
                    </tr>
                  </thead>
                  <tbody>  
                      <?php $__currentLoopData = $feed_member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fmember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($fmember->member_id); ?></td>
                          <td><?php echo e($fmember->name); ?></td>
                          <td><?php echo e($fmember->email); ?></td>
                          <td><?php echo e($fmember->mobile_number); ?></td>
                          <td><?php echo e($fmember->whatsapp_number); ?></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody> 
                </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>