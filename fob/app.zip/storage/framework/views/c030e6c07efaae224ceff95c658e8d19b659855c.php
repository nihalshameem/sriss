<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;background-color:#F3F8FA;">Advertisement Details<a href="<?php echo e(url( 'add_advertisement' )); ?>"><i class="fa fa-plus-square fa-lg" style="float:right"></i></a>
                <a href="<?php echo e(url( 'advertisement_mass_delete' )); ?>" title="Mass Deletion"><i class="fa fa-trash fa-lg " style="float:right;padding-right: 12px"></i></a></div>

                <div class="panel-body" style="text-align: left;">
                    
                    
                <table class="table">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Booked Date</th>
                      <th>Description</th>
                      <th>Company</th>
                      <!--<th>Image Path</th>
                      <th>Link</th>-->
                      <th>From Date</th>
                      <th>To Date</th>
                      <th>Active</th>
                      <th>Approval</th>
                      <th>Update</th>
                      <th>Receipt Update</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>  
                      <?php $__currentLoopData = $advertisements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($advertisement['id']); ?></td>
                          <td><?php echo e($advertisement['created_at']); ?></td>
                          <td><?php echo e($advertisement['description']); ?></td>
                          <td><?php echo e($advertisement['company']); ?></td>
                          <!--<td><?php echo e($advertisement['image_path']); ?></td>
                          <td><?php echo e($advertisement['link']); ?></td>-->
                          <td><?php echo e($advertisement['from_date']); ?></td>
                          <td><?php echo e($advertisement['to_date']); ?></td>
                          <td><?php echo e($advertisement['active']); ?></td>
                          
                          
                          
                          
                          
                          
                          
                          <!--<?php if($advertisement->active =='yes'): ?>-->
                          <!--<td><a href="/fob/advertisement_approval/<?php echo e($advertisement['id']); ?>" ><i class="fa fa-check fa-lg" style="text-align:cenetr;"></i></a></td>-->
                          <!--<?php else: ?>-->
                          <!--<td><a href="/fob/advertisement_approval/<?php echo e($advertisement['id']); ?>" ><i class="fa fa-remove fa-lg" style="text-align:cenetr;color:red"></i></a></td>-->
                          <!--<?php endif; ?>-->
                          
                          
    <?php if($advertisement->active =='yes'): ?>
        <td><i class="fa fa-check fa-lg" style="text-align:cenetr;color:blue;" onclick="Approve(<?php echo e($advertisement['id']); ?>)" ></i></td>
    <?php else: ?>
        <td><i class="fa fa-remove fa-lg" style="text-align:cenetr;color:blue;" onclick="Approve(<?php echo e($advertisement['id']); ?>)" ></i></td>
    <?php endif; ?>                   
                          
                          
                          
                          
                          
                          
                          <td><a href="/fob/advertisement_edit/<?php echo e($advertisement['id']); ?>" ><i class="fa fa-edit fa-lg" style="text-align:cenetr;"></i></a></td>
                          <td><a href="/fob/advertisement_receipt_edit/<?php echo e($advertisement['id']); ?>" ><i class="fa fa-edit fa-lg" style="text-align:cenetr;"></i></a></td>
                          
                          <?php if($advertisement->active =='yes'): ?>
                          <td><a href="" onclick="return alert('Active advertisements cannot be deleted!!')"><i class="fa fa-trash fa-lg" style="text-align:cenetr;"></i></a></td>
                          <?php else: ?>
                          <td><a href="/fob/advertisement_delete/<?php echo e($advertisement['id']); ?>" onclick="return confirm('Are you sure,You want to delete?')"><i class="fa fa-trash fa-lg" style="text-align:cenetr;"></i></a></td>
                          <?php endif; ?>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody> 
                </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('#advertisementsearch').on('change',function(){
      $value=$(this).val();
      $('#advertisementsearch1').on('change',function(){
      $value1=$(this).val();
      $.ajax({
        type : 'get',
        url : '<?php echo e(URL::to('advertisementsearch')); ?>',
        data : {'advertisementsearch':$value , 'advertisementsearch1':$value1},
        success:function(data){
          $('tbody').html(data);
        } 
      });
    })
    })
</script>





<script type="text/javascript">
    
   function Approve(id) {

        $.ajaxSetup({
               headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
               }
        });

        if( id !=""){

            $.ajax({
                 method: "POST",
                 url: "/fob/AjaxApproveAdver/"+id,
                 data: { id:id, }
                 }).done(function(data){  
                    console.log(data);
                    if(data.status==true)
                       {
                          location.reload(true);
                       }      
                       else
                       {
                          alert('Try Again!');
                          location.reload(true);
                       }     
                 });         
        }else{
            alert('Fill the required field');
        }

    }

</script>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>