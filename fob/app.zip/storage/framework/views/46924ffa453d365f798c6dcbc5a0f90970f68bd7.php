<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;background-color:#F3F8FA;">Feedback Details</div>

                <div class="panel-body" style="text-align: left;">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Member</th>
                      <th>Feedback</th>
                      <th>Date</th>
                      <th>Response</th>
                    </tr>
                  </thead>
                  <tbody>  
                      <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($feedback['id']); ?></td>
                          <td><a style="text-decoration:none;" href="/fob/feedback_info/<?php echo e($feedback['member_id']); ?>"><?php echo e($feedback['member_id']); ?></a></td>
                          <td><?php echo e($feedback['description']); ?></td>
                          <td><?php echo e($feedback['date']); ?></td>
                          <td><a href="/fob/feedbackMail/<?php echo e($feedback['id']); ?>" ><i class="fa fa-edit fa-lg" style="text-align:cenetr;"></i></a></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody> 
                </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>