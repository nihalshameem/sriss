<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row" style="margin-top:40px;">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;background-color:#F3F8FA;"><b>Visions</b><a href="<?php echo e(url( 'visionAdd' )); ?>"><i class="fa fa-plus-square fa-lg" style="float:right"></i></a>
                <?php if(Session::has('volunteer-added')): ?>
                <strong style="color:green;float:left;">Volunteer added success!!</strong> <?php echo e(Session::get('message', '')); ?>

                <?php endif; ?>
                </div>
                
                <div class="panel-body" style="text-align: left;">

                <div class="col-md-3 form-group">
                    <select name="vsearch" id="vsearch" class="form-control">
                          <option value="">Select Vision</option>
                          <?php $__currentLoopData = $cfgvisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($value->id); ?>"><?php echo e($value->vision); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                  </div>

                <table class="table">
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>Language</th>
                      <th>Vision</th>
                      <th>Description</th>
                      <th>Update</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>  

                <?php $i =1; ?>
                    <?php $__currentLoopData = $visions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                  $languageName = DB::table('cfg_languages')->where('id',$vision->languageId)->first();
                  $visionName = DB::table('cfg_visions')->where('id',$vision->typeId)->first();
                ?>
                       <tr>
                         <td><?php echo e($i++); ?></td>
                         <td><?php echo e($languageName->language); ?></td>
                         <td><?php echo e($visionName->vision); ?></td> 
                         <td><?php echo e($vision->description); ?></td> 
                         <td><a href="/fob/visionEdit/<?php echo e($vision->id); ?>" ><i class="fa fa-edit fa-lg" style="text-align:cenetr;"></i></a></td>
                         <td><a href="/fob/visionDelete/<?php echo e($vision->id); ?>" onclick="return confirm('Are you sure,You want to delete?')"><i class="fa fa-trash fa-lg" style="text-align:cenetr;"></i></a></td>
                       </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                  </tbody> 
                </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" >


<script type="text/javascript">
    $('#vsearch').on('change',function(){
      $value=$(this).val();
      $.ajax({
        type : 'get',
        url : '<?php echo e(URL::to('vsearch')); ?>',
        data : {'vsearch':$value},
        success:function(data){
          console.log(data);
          $('tbody').html(data);
        } 
      });
    })
  </script>

  <script language="JavaScript" type="text/javascript">
    function checkDelete(){
    return confirm('Are you sure?');
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>