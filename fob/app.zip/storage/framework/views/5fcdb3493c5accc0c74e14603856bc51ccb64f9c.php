<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;background-color:#F3F8FA;">Privacy Policy</div>

                <div class="panel-body" style="text-align: left;">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Description</th>
                      <th>Privacy Policy</th>
                      <th>Update</th>
                    </tr>
                  </thead>
                  <tbody>  
                      <?php $__currentLoopData = $idcardvision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idcard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($idcard['id']); ?></td>
                          <td><?php echo e($idcard['description']); ?></td>
                          <td><?php echo e($idcard['vision']); ?></td>
                          <td><a href="/fob/idcardvision_edit/<?php echo e($idcard['id']); ?>" ><i class="fa fa-edit fa-lg" style="text-align:cenetr;"></i></a></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody> 
                </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>