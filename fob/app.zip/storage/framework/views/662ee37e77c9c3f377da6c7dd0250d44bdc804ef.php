<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;background-color:#F3F8FA;"><a href="<?php echo e(redirect()->getUrlGenerator()->previous()); ?>"><i class="fa fa-arrow-left fa-lg" style="float:left"></i></a>Zone<?php echo e($zone['id']); ?> Districts<a href="/fob/add_zone_district/<?php echo e($zone['id']); ?>"><i class="fa fa-plus-square fa-lg" style="float:right" ></i></a></div>

                <div class="panel-body" style="text-align: left;">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>District</th>
                      <th>Description</th>
                    </tr>
                  </thead>
                  <tbody>  
                   <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($dist['id']); ?></td>
                        <td><?php echo e($dist['district']); ?></td>
                        <td><?php echo e($dist['description']); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody> 
                </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>