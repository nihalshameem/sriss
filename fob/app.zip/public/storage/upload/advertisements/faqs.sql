-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 25, 2018 at 10:53 AM
-- Server version: 5.5.61-38.13-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sriss_vruksham`
--

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vision` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `why_factor` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `faq` varchar(5000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `description`, `vision`, `why_factor`, `faq`, `created_at`, `updated_at`) VALUES
(1, 'vision', 'குறிக்கோள். (vision) \r\n\r\nநாம் நமது பொருளாதார தேடல் காரணமாகவும், மற்றும் பிற காரணங்களாலும் நமது ஹிந்து ஸனாதன அன்பர்கள் உலகமெங்கும் பரந்து விரிந்துள்ளோம். \r\n\r\nஇவர்கள் அனைவரையும் ஒரே குடையின் கீழ் கொண்டு வருவதே எங்களது தலையாய குறிக்கோள். அந்த குறிக்கோளையே முன்னிறுத்தி எங்களது டிரஸ்டின் பெயரை VruKShaM V(Vaishnavam)ruK(Krishnar)S(S(a)ivam)aM(Madvam) என்று நமது மூன்று பிரிவிகளையும் ஒன்று சேர்த்து ஸ்ரீ பகவான் கிருஷ்னரின் திருநாமத்தையும், அவரை சரணடைவோருக்கு யாதொரு கவலையும் இல்லை என உணர்த்தும் வாசகமான “மாஸுச:” என்ற வாக்கியத்தையும் இதில் இணைத்து  இந்த சிறு பணியை தொடங்கியுள்ளோம். \r\n\r\nஇந்த முயற்சி காலம் காலமாய் தொடர வேண்டும் என்பதை ப்ரதிபலிக்கும் விதமாக பல்லாண்டுகாலம் வாழும் ஆல மரத்தை நமது டிரஸ்டின் சின்னமாக தேர்ந்தெடுத்துள்ளோம். \r\n\r\nஇதற்கு இன்னும் வலு சேர்க்கும் விதமாக “एकता एव बलम” “Unity is strength” என்னும் வாக்கியத்தை இனைத்து நமது டிரஸ்டின் அடிப்படை குறிக்கோளை  எல்லோருக்கும் புரியும் விதமாக வடிவமைத்துள்ளோம். \r\n\r\nஎப்படி ஒரு மரம் தனது நிழலை யாதொரு பேதமும் இல்லாமல் எல்லோருக்கும் வழங்குகிறதோ, அதுபோல, நமது விஸ்வ ஸனாதன ஸமிதியில் யாதொரு பேதமும் இல்லாமல் அனைவரையும் சமமாக நடத்துவது என்பதை உறுதி கொண்டுள்ளோம்.', NULL, NULL, '2018-12-10 18:30:00', '2018-12-24 14:19:52'),
(2, 'Why Factor', NULL, NULL, NULL, '2018-12-10 18:30:00', '2018-12-19 14:35:06'),
(3, 'FAQ', 'கேள்வியும் & பதிலும்  \r\n\r\n1.	கே :VruKShaM விஸ்வ ஸனாதன ஸமிதியில் (VSS) எப்படி இணைவது? \r\n\r\nப : விஸ்வ ஸனாதன ஸமிதி (VSS) மொபைல் செயலியை முதலில் தரவிறக்கம் செய்து அதில் பதிவு செய்து கொள்ளவும். (Available on Google play store and IOS Platforms)\r\n\r\n2. கே : இந்த VSS ல் இணைவதற்கு கட்டணம் ஏதேனும் உண்டா? \r\n\r\nப : ஆம். தாங்கள் தங்களது வாழ்நாள் முழுவதும் இந்த VSSல் இணைந்திருப்பதேயே நாங்கள் எங்களுக்குத் தரும் ஆயுள் சந்தாவாக மனமுவந்து ஏற்றுக் கொள்கிறோம். \r\n\r\n3.	கே: நான் வேறு ஒரு ஸங்கத்தில் உறுப்பினராக இருந்து கொண்டு இங்கும் இணையலாமா?  \r\n\r\nப : நிச்சயமாக இணையலாம். எங்களது குறிக்கோள் எல்லோரையும்  நமது ஸனாதன ஸமிதியின் கீழ் ஒன்றினைப்பதே தலையாய குறிக்கோள். \r\n\r\n4.	நான் எனது உறவினர்களையும், மற்ற நண்பர்களையும் இதில் (VSS) இணைக்கலாமா?  \r\n\r\nப: நிச்சயமா இணைக்கலாம். இதற்கு நமது Mobile Appல் வசதி உள்ளது. நமது விஸ்வ ஸனாதன ஸமிதியில் இணையும் ஒவ்வொரு நபரும் குறைந்தது 10 அன்பர்களையாவது இணைத்து நமது முழு முதல் குறிக்கோளை( “एकता एव बलम” “Unity is strength”) அடைவதற்கு ஒத்துழைப்பு தருமாறு கேட்டுக் கொள்கிறோம்.  \r\n\r\n5.	நான் என் மூலமாக இணைந்தவர்களின் பட்டியலைப் பார்கக முடியுமா? \r\n\r\nப: ஆம். இதற்கு என்று ஒரு தனி பகுதி Mobile Appல் உள்ளது. அதுமட்டுமல்லாது, தாங்கள் இணைக்கும் ஒவ்வொருவருக்கும் நாங்கள் 10 ராம நாமாவை தங்களது கணக்கில் சேமிப்பாக இருப்பு வைக்கிறோம். \r\n\r\n6.	அடையாள அட்டை உண்டா? \r\n\r\nஆம். நமது விருக்ஷ்ம் டிரஸ்டின் செயல்பாடுகள் பல தரப்பட்ட மக்களின் தேவைகளை பூர்த்தி செய்யுமாறு வடிவமைந்துள்ளதாலும், மேலும் பல சேவைகளை பின் வரும் காலங்களில் அறிமுகப்படுத்த திட்டம் உள்ளதாலும், இவைகளை திறம்பட எந்த ஒரு நிர்வாகச் சிக்கல் இல்லாமல், நம்பகத்தன்மையுடனும் செய்வதற்கு அடையாள அட்டை மிக இன்றியமையாகிறது.  இதற்காக நாங்கள் ஒரு சிறு தொகையை தங்களிடமிருந்து பெற்றுக்கொண்டு, அடையாள அட்டையை தங்களது விலாசத்திற்கு தபால் மூலம் அனுப்பி வைக்கப்படும் என்பதை தெரிவித்துக் கொள்கிறோம்.  \r\n\r\n7.	விருக்ஷ்ம் டிரஸ்ட் முறையாக பதிவு செய்யப்பட்டுள்ளதா? \r\n\r\nஆம். “Charitable and Religious Trusts Act 1920” சட்ட விதியின் கீழ் பதிவு செய்யப்பட்டது. பதிவு எண் :________.', NULL, NULL, '2018-12-10 18:30:00', '2018-12-15 12:08:11'),
(4, 'Terms and Conditions', 'VruKSham Trust – Vishwa Sanadhana Samithi (VSS)\r\n\r\nGeneral Information\r\nThis Vishwa Sanadhana Samithi Mobile app (Hereafter this will refereed as VSS Mobile App)is owned and operated by  VruKShaM Trust Registration no ______________ in Chennai, India. Registered office address: VruKShaM Trust, 14/1, Sabari Deepam Flat, Ayyappan Nagar extension, Nanganallur, Chennai 600 061..\r\n\r\nSection 1\r\n1.1: Please read these terms carefully. They are a legal document and through using this VSS Mobile App you agree to be bound by them. If you do not accept these terms and/or do not wish to be bound by them, please exit this VSS Mobile App immediately and do not use it again in future.\r\n\r\n1.2: VruKShaM Trust may revise this document at any time. As such, you should visit this page periodically in order to review the Terms of Use because they are binding on you.\r\n1.3: In this document:\r\n1.3.1 References to ‘we’, ‘us’ or ‘our’ are references to VruKSham Trust / VSS Mobile app.\r\n1.3.2 ‘Customer’ means any person, company, organisation or firm that purchases services from us.\r\n1.3.3 ‘Order form’ means an order for services on a form provided by us (in any format).\r\n1.3.4 ‘Services’ means all products and services made available by us at any time.\r\n1.3.5 ‘Contract term’ means the full term specified in the order form.\r\n \r\nSection 2: Data Protection\r\n2.1: Our use of personal and other information supplied by users of this site is governed by our Privacy Policy.\r\n \r\nSection 3: Service Availability\r\n3.1: We try to ensure continuous availability of the VSS Mobile App and all the services available on it but accept no responsibility for the consequences of any interruptions or delays, however caused. We may, additionally, alter the design and specification of the VSS Mobile App at any time.\r\n \r\nSection 4: Commencement of Services (For Advertisements)\r\n4.1: We will not commence the provision of Services pursuant to any Order Form until the Order Form has been returned to us, in a form approved by us.\r\n \r\nSection 5: Refund, Replacement and Cancellation Terms (Not Applicable) \r\n5.1: Being this VSS Mobile App has been offered at free of cost this clause is not applicable. \r\n \r\nSection 6: Currency of Transactions\r\n6.1: We can issue invoices only in (INR) Rupees. Our preferred currency for payment is only in (INR) Rupees \r\n\r\nSection 7: Content and Links\r\n7.1: All the material on this VSS Mobile App is protected by copyright. You should not copy, download or reproduce content for your own personal/ commercial use. You should not use it for reproduction on another website, or in any way for commercial purposes or for any gain unless you have obtained express written consent from VruKShaM Trust.\r\n7.2: Where this VSS Mobile App provides links (if any) to other websites not produced by VruKShaM Trust, these links are provided for your convenience and do not signify that we endorse or have any responsibility for the content of those websites or for any transactions you enter relating to those linked sites.\r\n \r\nSection 8: Limitation of liability\r\n8.1: Our total liability to the Customer in respect of any Services, except for death or personal injury caused by our negligence, in this case, being it is a mobile application Sri Solutions and Services does not have any control on individual mobile use behaviour. Hence this is not applicable. \r\n \r\nSection 9: Passwords\r\n9.1: Passwords are for the sole use of the person to whom they are issued. We may deny access to a password if we reasonably believe that it is being used by an unauthorised person or that the user is breaching these Terms and Conditions.\r\n \r\nSection 10: Headings\r\n10.1: Any headings in these Terms and Conditions are for convenience only and shall not affect their construction.\r\n \r\nSection 11: Governing Law\r\n11.1: These Terms and Conditions shall be interpreted in accordance with Indian Law and all disputes shall be decided by the Indian Courts.\r\n\r\n11.2: If any part of these Terms and Conditions are held by a court of competent jurisdiction to be unenforceable, the validity of the remainder of these Terms and Conditions will not be affected.', NULL, NULL, NULL, '2018-12-25 06:59:33'),
(5, 'Privacy Policy', 'VruKShaM Trust understands the importance of maintaining the confidentiality of any information you may provide while using this VSS Mobile App. Any information we hold about you is provided only by you.\r\n \r\nGeneral Information\r\nIn general, we gather information about all our users collectively, such as what areas of this VSS Mobile App are visited most frequently and which of our services are accessed the most. We only use such data in an aggregate form. This information helps us determine what is most beneficial for our users, and how we can continually create a better overall experience for you.\r\nPlease note, we may record calls for training and monitoring purposes.\r\n\r\nUsing Information\r\nVruKShaM Trust will never sell or share personal information with third parties. We may use this information to serve those users who have requested to be mailed with issues that we feel they may be interested in, such as website and company news. Cookies are used for internal research and to give a better understanding of our audience.\r\nYou should also be aware that if you link out to third party websites, they have their own privacy policies for which Ama Vedic Services Limited can accept no responsibility. Please be certain to check other sites before use.\r\n \r\nCookies is this applicable for Mobile app? Need to validate. \r\nA cookie is a harmless piece of information that a website transfers to the cookie file of the browser on your computer’s hard drive. On visiting the website, a cookie will be placed on your computer automatically by the website. VSS Mobile App usesone typesof cookie from time to time: “session cookies”. Session cookies are temporary cookies that remain in the cookie file of your browser until you leave the website. VSS Mobile App does not use session cookies to store personal information about you.\r\n \r\nVSS Mobile App uses its cookies for monitoring load balancing between its servers while you are linked to the website, to conduct analyses of user traffic, and to perform web log audits. Third party advertisers may serve cookies via this website, but these are only used to serve advertisements from the website’s ad servers and to track whether these advertisements are clicked on by visitors to the website. VSS Mobile App may pass the non-personal information collected by its cookies to third parties but only for the purposes of carrying out such monitoring, analysis or web log auditing, or for the purposes of tracking the number of anonymous users of the website.\r\n \r\nMost browsers accept cookies automatically, but you have the ability to accept/decline cookies by altering the settings in your browser. If you decline/disable cookies, you may not be able to use all the interactive features of the website or the website may not be available to you.', NULL, NULL, NULL, '2018-12-25 07:00:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
