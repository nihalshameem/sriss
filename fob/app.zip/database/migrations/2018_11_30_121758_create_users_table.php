<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('member_id')->nullable();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('mobile_number');
            $table->string('password');
            $table->string('api_token',256)->nullable();
            $table->string('family')->nullable();
            $table->string('religion')->nullable();
            $table->string('marital')->nullable();
            $table->string('profession')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
