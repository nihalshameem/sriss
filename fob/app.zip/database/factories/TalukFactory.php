<?php

use Faker\Generator as Faker;

$factory->define(App\Taluk::class, function (Faker $faker) {
    return [
        //
    ];
});
