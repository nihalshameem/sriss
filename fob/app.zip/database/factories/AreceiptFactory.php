<?php

use Faker\Generator as Faker;

$factory->define(App\Areceipt::class, function (Faker $faker) {
    return [
        //
    ];
});
