<?php

use Faker\Generator as Faker;

$factory->define(App\Pollanswer::class, function (Faker $faker) {
    return [
        //
    ];
});
