<?php

use Faker\Generator as Faker;

$factory->define(App\Aos::class, function (Faker $faker) {
    return [
        //
    ];
});
