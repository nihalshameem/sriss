<?php

use Faker\Generator as Faker;

$factory->define(App\Tata::class, function (Faker $faker) {
    return [
        //
    ];
});
