<?php

use Faker\Generator as Faker;

$factory->define(App\Zone::class, function (Faker $faker) {
    return [
        //
    ];
});
