<?php

use Faker\Generator as Faker;

$factory->define(App\Pollquestion::class, function (Faker $faker) {
    return [
        //
    ];
});
