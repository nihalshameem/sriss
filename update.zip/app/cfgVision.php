<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cfgVision extends Model
{
    protected $table    ='cfg_visions';
    protected $fillable =[  
    						'vision',
    						];
}


