  <div class="navbar-fixed-bottom" style="background-color: #fafafa; height: 80px; border-top: 1px solid #dee2e6; ">
  	<div class="container">
  		<p style="text-align:center;color:#3a3a3a; padding-top: 30px;">Designed and Developed by <a  style="color:#3a3a3a;" target="blank">Sri Solutions & Services-9840515510</a></p>
  	</div>
  </div>

